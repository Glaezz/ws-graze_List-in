
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="d-none d-sm-table-row">
        <td> <?php echo e($user->username); ?> </td>
        <td> <?php echo e($user->file); ?> </td>
        <td>
        <span class="badge <?php echo e($badgeClass = $user->status === 'Pending' ? 'text-bg-secondary' : ($user->status === 'Done' ? 'text-bg-success' : 'text-bg-primary')); ?>" style="width: 72px; color: #fff"> <?php echo e($user->status); ?> </span>
        </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr class="d-sm-none">
         <th scope="row">
         <span style="font-weight: 400"><?php echo e($user->username); ?><br /><?php echo e($user->file); ?></span>
         </th>
         <td>
        <span class="badge <?php echo e($badgeClass = $user->status === 'Pending' ? 'text-bg-secondary' : ($user->status === 'Done' ? 'text-bg-success' : 'text-bg-primary')); ?>" style="width: 72px; color: #fff"> <?php echo e($user->status); ?> </span>
         </td>
         </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ws-graze\resources\views/userRead.blade.php ENDPATH**/ ?>